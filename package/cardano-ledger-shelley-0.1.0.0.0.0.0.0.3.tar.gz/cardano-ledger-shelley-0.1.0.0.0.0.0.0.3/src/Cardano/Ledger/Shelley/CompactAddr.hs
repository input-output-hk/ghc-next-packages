module Cardano.Ledger.Shelley.CompactAddr
  {-# DEPRECATED "Use 'import Cardano.Ledger.CompactAddress' instead" #-}
  ( module X,
  )
where

import Cardano.Ledger.CompactAddress as X
