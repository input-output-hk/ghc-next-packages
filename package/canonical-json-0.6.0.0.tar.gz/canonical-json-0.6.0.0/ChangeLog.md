# Revision history for canonical-json

## 0.6.0.0 2019-07-31

* Introduced JSString type rather than using String, for improved memory use.

* Improved parser performance

* Reduce stack space usage and introduce stack use tests

* Added benchmarks

## 0.5.0.1 2018-10-26

* ghc-8.4 compatibility.
* Move the test suite from the hackage-security library

## 0.5.0.0 2017-09-06

* Canonical JSON code extracted from hackage-security-0.5.2.2 into
  separate library.
