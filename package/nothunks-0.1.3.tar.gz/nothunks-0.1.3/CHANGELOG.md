# Revision history for nothunks

## 0.1.3 -- 2021-06-28

* Fix tests on ghc-9.0.1
  Joe Hermaszewski <git@monoid.al>
* Make bytestring, text and vector optional dependencies
  Bodigrim <andrew.lelechenko@gmail.com>

## 0.1.2 -- 2020-12-03

* Add IORef, MVar and TVar instances.
  Oleg Grenrus <oleg.grenrus@iki.fi>

## 0.1.1.0 -- 2020-09-29

* Export `Context` and `GWNoThunks`
* Fix typos in Haddocks
* Improve bounds (and add upper bounds)

## 0.1.0.0 -- 2020-09-09

* Initial public release
