{- | TODO An executable for Haskell implementation CLI testing/usage. -}

module Main (main) where

-- import PlutusConformance.Common

main :: IO ()
main = pure ()
