{-# LANGUAGE CPP #-}

#define BYTESTRING_LAZY

#include "ByteString.hs"
