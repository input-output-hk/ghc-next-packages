{-# LANGUAGE CPP #-}

#define BYTESTRING_SHORT

#include "ByteString.hs"
