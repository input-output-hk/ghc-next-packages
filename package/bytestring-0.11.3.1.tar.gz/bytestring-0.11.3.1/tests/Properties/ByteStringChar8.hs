{-# LANGUAGE CPP #-}

#define BYTESTRING_CHAR8

#include "ByteString.hs"
