{-# LANGUAGE CPP #-}

#define BYTESTRING_LAZY
#define BYTESTRING_CHAR8

#include "ByteString.hs"
