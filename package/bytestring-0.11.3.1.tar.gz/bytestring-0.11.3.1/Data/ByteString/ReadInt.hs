{-# LANGUAGE CPP #-}
#define BYTESTRING_STRICT
#include "Lazy/ReadInt.hs"
