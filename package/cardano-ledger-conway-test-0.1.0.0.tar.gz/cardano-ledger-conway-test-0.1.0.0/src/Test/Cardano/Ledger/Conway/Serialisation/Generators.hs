module Test.Cardano.Ledger.Conway.Serialisation.Generators () where

import Test.Cardano.Ledger.Babbage.Serialisation.Generators ()

-- Currently Conway does not define any types that require serialization,
-- therefore we simply re-export ones from Babbage. This could change in the
-- future, thus is this placeholder module.
