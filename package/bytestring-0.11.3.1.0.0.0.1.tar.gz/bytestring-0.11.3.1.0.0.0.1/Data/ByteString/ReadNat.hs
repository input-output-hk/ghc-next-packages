{-# LANGUAGE CPP #-}
#define BYTESTRING_STRICT
#include "Lazy/ReadNat.hs"
