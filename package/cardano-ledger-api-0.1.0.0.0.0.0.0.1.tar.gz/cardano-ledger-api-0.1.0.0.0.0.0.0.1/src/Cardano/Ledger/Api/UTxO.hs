module Cardano.Ledger.Api.UTxO
  ( UTxO (..),
    EraUTxO (..),
  )
where

import Cardano.Ledger.Shelley.UTxO (EraUTxO (..), UTxO (..))
