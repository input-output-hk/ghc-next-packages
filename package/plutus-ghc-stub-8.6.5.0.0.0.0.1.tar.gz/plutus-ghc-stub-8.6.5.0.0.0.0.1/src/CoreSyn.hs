module CoreSyn where

import StubTypes
