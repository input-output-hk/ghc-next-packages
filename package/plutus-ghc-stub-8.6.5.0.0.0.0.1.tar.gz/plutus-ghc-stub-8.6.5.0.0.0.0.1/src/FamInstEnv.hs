module FamInstEnv where

import StubTypes
