{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

-- | Defines reusable abstractions for testing Roundtrip properties of CBOR instances
module Data.Roundtrip
  ( roundTrip,
    roundTrip',
    embedTrip,
    embedTrip',
    roundTripAnn,
    roundTripAnnWithTwiddling,
    roundTripWithTwiddling,
    embedTripAnn,
    RoundTripResult,
  )
where

import Cardano.Binary
  ( Annotator (..),
    FromCBOR (fromCBOR),
    FullByteString (Full),
    ToCBOR (toCBOR),
  )
import Codec.CBOR.Decoding (Decoder)
import Codec.CBOR.Encoding (Encoding)
import Codec.CBOR.Read
  ( DeserialiseFailure,
    deserialiseFromBytes,
  )
import Codec.CBOR.Term (encodeTerm)
import Codec.CBOR.Write (toLazyByteString)
import qualified Data.ByteString.Lazy as LBS
import qualified Data.ByteString.Lazy as Lazy
import Data.Twiddle (Twiddle (..))
import Test.QuickCheck (Gen)

-- =====================================================================

type RoundTripResult t = Either Codec.CBOR.Read.DeserialiseFailure (Lazy.ByteString, t)

roundTrip :: (ToCBOR t, FromCBOR t) => t -> RoundTripResult t
roundTrip s = deserialiseFromBytes fromCBOR (toLazyByteString (toCBOR s))

roundTrip' :: (t -> Encoding) -> (forall s. Decoder s t) -> t -> RoundTripResult t
roundTrip' enc dec t = deserialiseFromBytes dec (toLazyByteString (enc t))

roundTripAnn :: (ToCBOR t, FromCBOR (Annotator t)) => t -> RoundTripResult t
roundTripAnn s = roundTripAnnBytes $ toLazyByteString (toCBOR s)

roundTripAnnWithTwiddling ::
  forall t.
  (Twiddle t, FromCBOR (Annotator t)) =>
  t ->
  Gen (RoundTripResult t, LBS.ByteString)
roundTripAnnWithTwiddling x = do
  tw <- encodeTerm <$> twiddle x
  let bs = toLazyByteString tw
  pure (roundTripAnnBytes bs, bs)

roundTripWithTwiddling :: (Twiddle t, FromCBOR t) => t -> Gen (RoundTripResult t, LBS.ByteString)
roundTripWithTwiddling x = do
  tw <- encodeTerm <$> twiddle x
  let bs = toLazyByteString tw
  pure (roundTrip' (const tw) fromCBOR x, bs)

roundTripAnnBytes :: FromCBOR (Annotator t) => Lazy.ByteString -> RoundTripResult t
roundTripAnnBytes bytes = case deserialiseFromBytes fromCBOR bytes of
  Left err -> Left err
  Right (leftover, Annotator f) -> Right (leftover, f (Full bytes))

-- | Can we serialise a type, and then deserialise it as something else?
embedTrip :: (ToCBOR t, FromCBOR s) => t -> RoundTripResult s
embedTrip s = deserialiseFromBytes fromCBOR (toLazyByteString (toCBOR s))

embedTrip' :: (s -> Encoding) -> (forall x. Decoder x t) -> s -> RoundTripResult t
embedTrip' enc dec s = deserialiseFromBytes dec (toLazyByteString (enc s))

embedTripAnn :: forall s t. (ToCBOR t, FromCBOR (Annotator s)) => t -> RoundTripResult s
embedTripAnn s =
  let bytes = toLazyByteString (toCBOR s)
   in case deserialiseFromBytes fromCBOR bytes of
        Left err -> Left err
        Right (leftover, Annotator f) -> Right (leftover, f (Full bytes))
